动物倒数乐园｜40以内减法互动网页

文件：
- index.html：完整网页游戏，可离线打开，也可免费发布到网上。

本地试玩：
1. 下载并解压 ZIP。
2. 双击 index.html，用 Chrome、Edge 或 Safari 打开。
3. 点击答案进行游戏。

免费发布方法（GitHub Pages）：
1. 登录 https://github.com/ 并创建免费账号（如已有账号直接登录）。
2. 点击 New repository，新建仓库，例如 animal-countdown-game。
3. 选择 Public，创建仓库。
4. 在仓库页面点击 Add file → Upload files，把 index.html 上传，然后点击 Commit changes。
5. 打开仓库 Settings → Pages。
6. 在 Build and deployment 下选择 Deploy from a branch。
7. Branch 选择 main，文件夹选择 /(root)，点击 Save。
8. 等待一两分钟，刷新 Pages 页面，就会出现可分享的网站网址，通常形如：
   https://你的GitHub用户名.github.io/animal-countdown-game/
9. 把网址发给家长，学生就可以用手机、平板或电脑打开。

注意：
- 网站无需安装，不需要学生注册。
- 此版本在学生设备上即时计算分数，不会收集或上传学生姓名、成绩或其他个人资料。
- 若要由老师集中查看全班成绩，需要另外添加安全的成绩储存/提交功能。
